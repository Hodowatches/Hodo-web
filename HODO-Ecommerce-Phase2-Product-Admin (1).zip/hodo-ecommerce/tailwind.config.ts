import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  theme: { extend: { colors: { ink: "#111111", paper: "#FFFFFF", mist: "#F3F3F3" } } },
  plugins: []
} satisfies Config;
