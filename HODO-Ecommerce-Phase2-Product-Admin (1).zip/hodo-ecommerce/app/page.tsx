import Link from "next/link";
import { ProductCard } from "@/components/product-card";
import { getFeaturedProducts } from "@/lib/products";

export default async function HomePage() {
  const products = await getFeaturedProducts();
  return <main>
    <section className="bg-neutral-100">
      <div className="container-shell grid min-h-[570px] items-center gap-10 py-16 md:grid-cols-2 md:py-20">
        <div><p className="eyebrow">HODO / WATCHES & FRAGRANCES</p><h1 className="mt-5 max-w-xl text-5xl font-semibold leading-[.98] tracking-[-.06em] sm:text-7xl">TIMELESS<br/>STYLE.<br/>SIGNATURE SCENT.</h1>
          <p className="mt-6 max-w-md text-sm leading-7 text-neutral-600">A considered collection of watches and fragrances for every day, every moment.</p>
          <div className="mt-8 flex flex-wrap gap-3"><Link className="btn-primary" href="/shop">Explore collection</Link><Link className="btn-secondary" href="/shop?category=perfume">Shop perfumes</Link></div></div>
        <div className="relative aspect-[4/5] overflow-hidden bg-neutral-200">
          <img className="h-full w-full object-cover" src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1200&q=85" alt="Minimal wristwatch campaign"/>
          <div className="absolute bottom-5 left-5 bg-white px-4 py-3 text-xs tracking-widest">THE EVERYDAY COLLECTION</div>
        </div>
      </div>
    </section>
    <section className="container-shell py-20">
      <div className="flex items-end justify-between"><div><p className="eyebrow">CURATED FOR YOU</p><h2 className="section-title mt-3">Featured pieces</h2></div><Link href="/shop" className="border-b border-black pb-1 text-xs">VIEW ALL</Link></div>
      {products.length ? <div className="mt-9 grid grid-cols-2 gap-x-5 gap-y-10 md:grid-cols-4">{products.map(p=><ProductCard key={p.id} product={p}/>)}</div> :
        <div className="mt-8 border border-dashed p-10 text-center text-sm text-neutral-500">Products will appear here after you add them in the HODO Admin Dashboard.</div>}
    </section>
    <section id="about" className="bg-black py-16 text-white"><div className="container-shell grid gap-5 md:grid-cols-2"><p className="eyebrow text-neutral-400">THE HODO STANDARD</p><div><h2 className="section-title">Details matter.<br/>Make them yours.</h2><p className="mt-5 max-w-lg text-sm leading-7 text-neutral-400">Explore thoughtfully selected watches and fragrances, with simple ordering and personal service.</p></div></div></section>
  </main>;
}
