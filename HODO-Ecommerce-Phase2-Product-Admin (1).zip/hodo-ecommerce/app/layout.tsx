import type { Metadata } from "next";
import "./globals.css";
import { StoreHeader } from "@/components/store-header";

export const metadata: Metadata = {
  title: "HODO | Watches & Perfumes",
  description: "Discover watches and signature fragrances at HODO."
};
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="en"><body><StoreHeader/>{children}<footer id="contact" className="mt-24 border-t py-10">
    <div className="container-shell flex flex-col justify-between gap-5 sm:flex-row"><div><div className="font-black tracking-[.25em]">HODO</div><p className="mt-2 text-xs text-neutral-500">TIMELESS STYLE. SIGNATURE SCENT.</p></div>
    <div className="text-xs text-neutral-500">Watches · Perfumes · Phnom Penh, Cambodia<br/>© {new Date().getFullYear()} HODO. All rights reserved.</div></div>
  </footer></body></html>;
}
