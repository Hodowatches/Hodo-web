import { createClient } from "@/lib/supabase/server";
import { AddToCart } from "@/components/add-to-cart";
import { moneyBoth } from "@/lib/money";
import { notFound } from "next/navigation";

export default async function ProductPage({params}:{params:Promise<{slug:string}>}) {
  const {slug} = await params;
  const supabase = await createClient();
  const {data: product} = await supabase.from("products").select("*").eq("slug",slug).eq("is_active",true).single();
  if (!product) notFound();
  return <main className="container-shell grid gap-10 py-12 md:grid-cols-2 md:py-20">
    <div className="aspect-[4/5] bg-neutral-100">{product.image_url && <img src={product.image_url} alt={product.name_en} className="h-full w-full object-cover"/>}</div>
    <div className="self-center"><p className="eyebrow">{product.category} / {product.brand || "HODO COLLECTION"}</p><h1 className="mt-4 text-4xl font-semibold tracking-tight">{product.name_en}</h1>{product.name_kh && <p className="mt-2 text-neutral-500">{product.name_kh}</p>}
      <p className="mt-6 text-xl">{moneyBoth(Number(product.price))}</p><p className="mt-6 text-sm leading-7 text-neutral-600">{product.description_en}</p>
      <p className="mt-6 text-xs text-neutral-500">{product.stock > 0 ? `${product.stock} available` : "Out of stock"}</p>
      <div className="mt-8 max-w-sm"><AddToCart productId={product.id} disabled={product.stock < 1}/></div>
    </div>
  </main>;
}
