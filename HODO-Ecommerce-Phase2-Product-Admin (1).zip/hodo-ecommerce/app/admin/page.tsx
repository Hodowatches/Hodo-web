import { AdminProducts } from "@/components/admin-products";

export default function AdminPage() {
  return <main className="container-shell min-h-[70vh] py-10"><p className="eyebrow">HODO / MANAGEMENT</p><h1 className="section-title mt-3">Product management</h1><p className="mt-3 max-w-2xl text-sm leading-7 text-neutral-600">Sign in with the administrator account you created in Supabase. Only accounts listed in the HODO admin_users table can manage products.</p><div className="mt-8"><AdminProducts /></div></main>;
}
