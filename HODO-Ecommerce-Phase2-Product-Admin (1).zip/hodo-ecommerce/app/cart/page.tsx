import Link from "next/link";
export default function CartPage() {
  return <main className="container-shell min-h-[60vh] py-16"><p className="eyebrow">HODO / YOUR BAG</p><h1 className="section-title mt-3">Shopping bag</h1>
    <div className="mt-8 max-w-2xl border p-6"><p className="text-sm text-neutral-600">Your cart is stored in this browser. Cart review and secure checkout are the next implementation milestone.</p><Link className="btn-primary mt-6" href="/shop">Continue shopping</Link></div>
  </main>;
}
