import { getProducts } from "@/lib/products";
import { ProductCard } from "@/components/product-card";

export default async function ShopPage({searchParams}:{searchParams:Promise<{category?:string}>}) {
  const params = await searchParams;
  const products = await getProducts(params.category);
  const heading = params.category === "watch" ? "Watches" : params.category === "perfume" ? "Perfumes" : "All collections";
  return <main className="container-shell min-h-[60vh] py-14"><p className="eyebrow">HODO / SHOP</p><h1 className="section-title mt-3">{heading}</h1>
    <div className="mt-6 flex gap-3 text-xs"><a className="border px-4 py-2" href="/shop">ALL</a><a className="border px-4 py-2" href="/shop?category=watch">WATCHES</a><a className="border px-4 py-2" href="/shop?category=perfume">PERFUMES</a></div>
    {products.length ? <div className="mt-9 grid grid-cols-2 gap-x-5 gap-y-10 md:grid-cols-4">{products.map(p=><ProductCard key={p.id} product={p}/>)}</div> : <p className="mt-10 bg-neutral-50 p-10 text-center text-sm text-neutral-500">No products found yet. Add products from the admin tools after database setup.</p>}
  </main>;
}
