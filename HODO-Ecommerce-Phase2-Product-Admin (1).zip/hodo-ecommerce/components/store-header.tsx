"use client";
import Link from "next/link";
import { useState } from "react";
import { ShoppingBag, Menu, X } from "lucide-react";

export function StoreHeader() {
  const [open, setOpen] = useState(false);
  return <header className="sticky top-0 z-30 border-b border-neutral-200 bg-white/95 backdrop-blur">
    <div className="container-shell flex h-16 items-center justify-between">
      <Link href="/" className="text-2xl font-black tracking-[.22em]">HODO</Link>
      <nav className="hidden items-center gap-8 text-sm md:flex">
        <Link href="/shop?category=watch">WATCHES</Link><Link href="/shop?category=perfume">PERFUMES</Link>
        <Link href="/#about">ABOUT</Link><Link href="/#contact">CONTACT</Link>
      </nav>
      <div className="flex items-center gap-3">
        <Link href="/cart" aria-label="Shopping cart" className="rounded-full border p-2"><ShoppingBag size={18}/></Link>
        <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Toggle menu">{open ? <X/> : <Menu/>}</button>
      </div>
    </div>
    {open && <nav className="grid gap-4 border-t px-6 py-5 text-sm md:hidden">
      <Link onClick={() => setOpen(false)} href="/shop?category=watch">WATCHES</Link>
      <Link onClick={() => setOpen(false)} href="/shop?category=perfume">PERFUMES</Link>
      <Link onClick={() => setOpen(false)} href="/#about">ABOUT</Link>
    </nav>}
  </header>;
}
