import Link from "next/link";
import type { Product } from "@/lib/types";
import { moneyBoth } from "@/lib/money";

export function ProductCard({ product }: { product: Product }) {
  return <Link href={`/product/${product.slug}`} className="group block">
    <div className="aspect-[4/5] overflow-hidden bg-neutral-100">
      {product.image_url ? <img src={product.image_url} alt={product.name_en} className="h-full w-full object-cover transition duration-500 group-hover:scale-105"/> :
        <div className="flex h-full items-center justify-center text-xs tracking-widest text-neutral-400">HODO PRODUCT</div>}
    </div>
    <div className="pt-3">
      <div className="flex items-start justify-between gap-2"><h3 className="font-medium">{product.name_en}</h3></div>
      <p className="mt-1 text-sm text-neutral-500">{product.brand || (product.category === "watch" ? "Watch" : "Perfume")}</p>
      <p className="mt-2 text-sm font-semibold">{moneyBoth(Number(product.price))}</p>
    </div>
  </Link>;
}
