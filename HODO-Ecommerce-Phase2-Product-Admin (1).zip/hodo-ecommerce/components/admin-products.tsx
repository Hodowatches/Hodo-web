"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { moneyBoth } from "@/lib/money";

type Row = { id: string; name_en: string; name_km: string | null; slug: string; category: "watch" | "perfume"; brand: string | null; description_en: string | null; description_km: string | null; price: number; compare_at_price: number | null; stock: number; sku: string | null; image_url: string | null; is_active: boolean; };
type FormState = { name_en: string; name_km: string; slug: string; category: "watch" | "perfume"; brand: string; description_en: string; description_km: string; price: string; compare_at_price: string; stock: string; sku: string; is_active: boolean; };
const blank: FormState = { name_en: "", name_km: "", slug: "", category: "watch", brand: "HODO", description_en: "", description_km: "", price: "", compare_at_price: "", stock: "0", sku: "", is_active: true };
const slugify = (s: string) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

export function AdminProducts() {
  const supabase = useMemo(() => createClient(), []);
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [userId, setUserId] = useState<string | null>(null); const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false); const [message, setMessage] = useState("");
  const [products, setProducts] = useState<Row[]>([]); const [editing, setEditing] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(blank); const [image, setImage] = useState<File | null>(null);
  const [filter, setFilter] = useState<"all" | "watch" | "perfume">("all");

  async function verifyAdmin(uid: string) {
    const { data, error } = await supabase.from("admin_users").select("user_id,is_active").eq("user_id", uid).maybeSingle();
    if (error || !data?.is_active) { await supabase.auth.signOut(); setUserId(null); setMessage("This account is not an active HODO administrator. Check the admin_users record."); return false; }
    setUserId(uid); return true;
  }
  async function loadProducts() {
    const { data, error } = await supabase.from("products").select("*").order("created_at", { ascending: false });
    if (error) setMessage(error.message); else setProducts((data || []) as Row[]);
  }
  useEffect(() => { (async () => { const { data } = await supabase.auth.getUser(); if (data.user) { const ok = await verifyAdmin(data.user.id); if (ok) await loadProducts(); } setLoading(false); })(); }, []);

  async function signIn(e: FormEvent) { e.preventDefault(); setBusy(true); setMessage(""); const { data, error } = await supabase.auth.signInWithPassword({ email, password }); if (error || !data.user) setMessage(error?.message || "Unable to sign in."); else if (await verifyAdmin(data.user.id)) await loadProducts(); setBusy(false); }
  function startEdit(p: Row) { setEditing(p.id); setImage(null); setForm({ name_en: p.name_en, name_km: p.name_km || "", slug: p.slug, category: p.category, brand: p.brand || "", description_en: p.description_en || "", description_km: p.description_km || "", price: String(p.price), compare_at_price: p.compare_at_price == null ? "" : String(p.compare_at_price), stock: String(p.stock), sku: p.sku || "", is_active: p.is_active }); window.scrollTo({ top: 0, behavior: "smooth" }); }
  function resetForm() { setEditing(null); setImage(null); setForm(blank); }
  async function saveProduct(e: FormEvent) {
    e.preventDefault(); if (!userId) return; setBusy(true); setMessage("");
    try {
      let image_url: string | null = null;
      if (image) { const safeName = image.name.replace(/[^a-zA-Z0-9._-]/g, "-"); const path = `${Date.now()}-${safeName}`; const { error: uploadError } = await supabase.storage.from("hodo-products").upload(path, image, { upsert: false, contentType: image.type }); if (uploadError) throw uploadError; image_url = supabase.storage.from("hodo-products").getPublicUrl(path).data.publicUrl; }
      const payload = { name_en: form.name_en.trim(), name_km: form.name_km.trim() || null, slug: slugify(form.slug || form.name_en), category: form.category, brand: form.brand.trim() || "HODO", description_en: form.description_en.trim() || null, description_km: form.description_km.trim() || null, price: Number(form.price), compare_at_price: form.compare_at_price ? Number(form.compare_at_price) : null, stock: Math.max(0, Math.floor(Number(form.stock))), sku: form.sku.trim() || null, is_active: form.is_active, ...(image_url ? { image_url } : {}) };
      if (!payload.name_en || !payload.slug || !Number.isFinite(payload.price) || payload.price < 0 || !Number.isFinite(payload.stock)) throw new Error("Enter a product name, valid price and stock quantity.");
      const result = editing ? await supabase.from("products").update(payload).eq("id", editing) : await supabase.from("products").insert(payload);
      if (result.error) throw result.error;
      setMessage(editing ? "Product updated." : "Product added to the HODO catalogue."); resetForm(); await loadProducts();
    } catch (err) { setMessage(err instanceof Error ? err.message : "Unable to save product."); }
    setBusy(false);
  }
  async function deactivate(id: string) { if (!confirm("Deactivate this product? It will no longer appear in the customer store.")) return; setBusy(true); const { error } = await supabase.from("products").update({ is_active: false }).eq("id", id); setMessage(error?.message || "Product deactivated."); await loadProducts(); setBusy(false); }
  async function signOut() { await supabase.auth.signOut(); setUserId(null); setProducts([]); resetForm(); }
  const shown = products.filter(p => filter === "all" || p.category === filter);

  if (loading) return <p className="border p-6 text-sm">Checking administrator access…</p>;
  if (!userId) return <form onSubmit={signIn} className="max-w-md border p-6"><h2 className="text-xl font-semibold">Administrator sign in</h2><label className="mt-5 block text-xs">Email<input required type="email" autoComplete="username" value={email} onChange={e => setEmail(e.target.value)} className="mt-2 w-full border p-3 text-sm" /></label><label className="mt-4 block text-xs">Password<input required type="password" autoComplete="current-password" value={password} onChange={e => setPassword(e.target.value)} className="mt-2 w-full border p-3 text-sm" /></label><button disabled={busy} className="btn-primary mt-5 w-full">{busy ? "Signing in…" : "Sign in"}</button>{message && <p role="alert" className="mt-4 text-sm text-red-700">{message}</p>}<p className="mt-4 text-xs leading-5 text-neutral-500">Create the user first in Supabase Authentication, then add that user's UUID to public.admin_users. Never share your password or secret API key.</p></form>;

  return <div><div className="flex flex-wrap items-center justify-between gap-3 border-b pb-4"><div><p className="text-xs text-neutral-500">SIGNED IN AS ADMIN</p><h2 className="mt-1 font-semibold">Catalogue · {products.length} products</h2></div><button onClick={signOut} className="btn-secondary">Sign out</button></div>
    <form onSubmit={saveProduct} className="mt-6 grid gap-4 border p-5 md:grid-cols-2"><div className="md:col-span-2 flex items-center justify-between"><h3 className="text-lg font-semibold">{editing ? "Edit product" : "Add a product"}</h3>{editing && <button type="button" onClick={resetForm} className="text-xs underline">Cancel edit</button>}</div>
      <label className="text-xs">Product name (English)<input required value={form.name_en} onChange={e => setForm({...form,name_en:e.target.value,slug: form.slug || slugify(e.target.value)})} className="mt-2 w-full border p-3 text-sm" /></label>
      <label className="text-xs">Product name (Khmer)<input value={form.name_km} onChange={e => setForm({...form,name_km:e.target.value})} className="mt-2 w-full border p-3 text-sm" /></label>
      <label className="text-xs">Category<select value={form.category} onChange={e => setForm({...form,category:e.target.value as "watch" | "perfume"})} className="mt-2 w-full border p-3 text-sm"><option value="watch">Watch</option><option value="perfume">Perfume</option></select></label>
      <label className="text-xs">Brand<input value={form.brand} onChange={e => setForm({...form,brand:e.target.value})} className="mt-2 w-full border p-3 text-sm" /></label>
      <label className="text-xs">SKU<input value={form.sku} onChange={e => setForm({...form,sku:e.target.value})} className="mt-2 w-full border p-3 text-sm" /></label>
      <label className="text-xs">URL slug<input required value={form.slug} onChange={e => setForm({...form,slug:slugify(e.target.value)})} className="mt-2 w-full border p-3 text-sm" /></label>
      <label className="text-xs">Price (USD)<input required type="number" min="0" step="0.01" value={form.price} onChange={e => setForm({...form,price:e.target.value})} className="mt-2 w-full border p-3 text-sm" /></label>
      <label className="text-xs">Compare-at price (USD)<input type="number" min="0" step="0.01" value={form.compare_at_price} onChange={e => setForm({...form,compare_at_price:e.target.value})} className="mt-2 w-full border p-3 text-sm" /></label>
      <label className="text-xs">Stock quantity<input required type="number" min="0" step="1" value={form.stock} onChange={e => setForm({...form,stock:e.target.value})} className="mt-2 w-full border p-3 text-sm" /></label>
      <label className="text-xs">Product photo (JPEG / PNG / WebP, max 5 MB)<input type="file" accept="image/jpeg,image/png,image/webp" onChange={e => setImage(e.target.files?.[0] || null)} className="mt-2 block w-full text-sm" /></label>
      <label className="text-xs md:col-span-2">Description (English)<textarea rows={3} value={form.description_en} onChange={e => setForm({...form,description_en:e.target.value})} className="mt-2 w-full border p-3 text-sm" /></label>
      <label className="text-xs md:col-span-2">Description (Khmer)<textarea rows={3} value={form.description_km} onChange={e => setForm({...form,description_km:e.target.value})} className="mt-2 w-full border p-3 text-sm" /></label>
      <label className="flex items-center gap-2 text-xs md:col-span-2"><input type="checkbox" checked={form.is_active} onChange={e => setForm({...form,is_active:e.target.checked})}/> Visible in customer store</label>
      <div className="md:col-span-2 flex flex-wrap items-center gap-3"><button disabled={busy} className="btn-primary">{busy ? "Saving…" : editing ? "Save changes" : "Add product"}</button>{message && <p role="status" className="text-sm text-neutral-600">{message}</p>}</div>
    </form>
    <div className="mt-10 flex flex-wrap items-center justify-between gap-3"><h3 className="text-xl font-semibold">Your products</h3><select value={filter} onChange={e => setFilter(e.target.value as typeof filter)} className="border p-2 text-xs"><option value="all">All categories</option><option value="watch">Watches</option><option value="perfume">Perfumes</option></select></div>
    <div className="mt-4 divide-y border">{shown.map(p => <div key={p.id} className="flex flex-wrap items-center gap-4 p-4"><div className="h-16 w-14 shrink-0 bg-neutral-100">{p.image_url && <img src={p.image_url} alt={p.name_en} className="h-full w-full object-cover"/>}</div><div className="min-w-0 flex-1"><p className="font-medium">{p.name_en}</p><p className="mt-1 text-xs text-neutral-500">{p.category.toUpperCase()} · {p.sku || "No SKU"} · Stock: {p.stock} · {moneyBoth(Number(p.price))}</p></div><span className={`text-[10px] tracking-widest ${p.is_active ? "text-green-700" : "text-neutral-400"}`}>{p.is_active ? "ACTIVE" : "HIDDEN"}</span><button onClick={() => startEdit(p)} className="border px-3 py-2 text-xs">Edit</button>{p.is_active && <button onClick={() => deactivate(p.id)} disabled={busy} className="border px-3 py-2 text-xs">Deactivate</button>}</div>)}{shown.length === 0 && <p className="p-8 text-center text-sm text-neutral-500">No products in this category yet.</p>}</div>
  </div>;
}
