"use client";
import { useState } from "react";
import { ShoppingBag } from "lucide-react";

export function AddToCart({ productId, disabled = false }: { productId: string; disabled?: boolean }) {
  const [added, setAdded] = useState(false);
  function add() {
    const cart = JSON.parse(localStorage.getItem("hodo-cart") || "[]") as {productId:string;quantity:number}[];
    const found = cart.find(x => x.productId === productId);
    if (found) found.quantity += 1; else cart.push({ productId, quantity: 1 });
    localStorage.setItem("hodo-cart", JSON.stringify(cart));
    setAdded(true);
    window.dispatchEvent(new Event("hodo-cart-updated"));
  }
  return <button disabled={disabled} onClick={add} className="btn-primary w-full disabled:cursor-not-allowed disabled:opacity-40">
    <ShoppingBag size={16}/>{disabled ? "Out of stock" : added ? "Added to cart" : "Add to cart"}
  </button>;
}
