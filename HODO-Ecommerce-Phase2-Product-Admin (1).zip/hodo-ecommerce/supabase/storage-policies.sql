-- Run only after creating the public `hodo-products` bucket in Supabase Storage.
-- Supabase Dashboard > Storage > New bucket > hodo-products > Public bucket ON.

drop policy if exists "Public view HODO product images" on storage.objects;
create policy "Public view HODO product images"
on storage.objects for select to anon, authenticated
using (bucket_id = 'hodo-products');

drop policy if exists "HODO admins upload product images" on storage.objects;
create policy "HODO admins upload product images"
on storage.objects for insert to authenticated
with check (bucket_id = 'hodo-products' and (select public.is_admin()));

drop policy if exists "HODO admins update product images" on storage.objects;
create policy "HODO admins update product images"
on storage.objects for update to authenticated
using (bucket_id = 'hodo-products' and (select public.is_admin()))
with check (bucket_id = 'hodo-products' and (select public.is_admin()));

drop policy if exists "HODO admins delete product images" on storage.objects;
create policy "HODO admins delete product images"
on storage.objects for delete to authenticated
using (bucket_id = 'hodo-products' and (select public.is_admin()));
