-- HODO E-Commerce initial schema
create extension if not exists pgcrypto;

create type public.product_category as enum ('watch','perfume');
create type public.order_status as enum ('pending','confirmed','preparing','shipping','delivered','cancelled');
create type public.payment_method as enum ('aba_transfer','khqr','cash_on_delivery');
create type public.payment_status as enum ('unpaid','proof_submitted','verified','failed','refunded');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'customer' check (role in ('customer','admin','sales','stock','accountant')),
  phone text,
  created_at timestamptz not null default now()
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name_en text not null,
  name_kh text,
  slug text not null unique,
  created_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  category public.product_category not null,
  category_id uuid references public.categories(id),
  name_en text not null,
  name_kh text,
  slug text not null unique,
  brand text,
  model text,
  description_en text,
  description_kh text,
  price numeric(12,2) not null check (price >= 0),
  compare_at_price numeric(12,2) check (compare_at_price is null or compare_at_price >= 0),
  cost_price numeric(12,2) check (cost_price is null or cost_price >= 0),
  sku text not null unique,
  image_url text,
  is_active boolean not null default true,
  is_featured boolean not null default false,
  stock_quantity integer not null default 0 check (stock_quantity >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  sku text not null unique,
  variant_label text not null,
  color text,
  volume_ml integer,
  attributes jsonb not null default '{}'::jsonb,
  price_override numeric(12,2),
  stock_quantity integer not null default 0 check (stock_quantity >= 0),
  created_at timestamptz not null default now()
);

create table public.customers (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  phone text not null,
  email text,
  created_at timestamptz not null default now()
);

create table public.customer_addresses (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references public.customers(id) on delete cascade,
  recipient_name text not null,
  phone text not null,
  address_line text not null,
  city text,
  province text,
  delivery_note text,
  created_at timestamptz not null default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  customer_id uuid references public.customers(id),
  guest_name text not null,
  guest_phone text not null,
  delivery_address jsonb not null,
  status public.order_status not null default 'pending',
  payment_method public.payment_method not null,
  payment_status public.payment_status not null default 'unpaid',
  currency text not null default 'USD' check (currency in ('USD','KHR')),
  subtotal numeric(12,2) not null check (subtotal >= 0),
  discount_amount numeric(12,2) not null default 0 check (discount_amount >= 0),
  delivery_fee numeric(12,2) not null default 0 check (delivery_fee >= 0),
  total_amount numeric(12,2) not null check (total_amount >= 0),
  customer_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id),
  variant_id uuid references public.product_variants(id),
  product_name_snapshot text not null,
  sku_snapshot text not null,
  quantity integer not null check (quantity > 0),
  unit_price numeric(12,2) not null check (unit_price >= 0),
  unit_cost numeric(12,2),
  line_total numeric(12,2) not null check (line_total >= 0)
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  method public.payment_method not null,
  amount numeric(12,2) not null check (amount >= 0),
  transaction_reference text,
  proof_image_url text,
  status public.payment_status not null default 'unpaid',
  verified_by uuid references auth.users(id),
  verified_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.inventory_transactions (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id),
  variant_id uuid references public.product_variants(id),
  transaction_type text not null check (transaction_type in ('stock_in','stock_out','adjustment','sale','return')),
  quantity integer not null,
  reason text,
  reference_id uuid,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.deliveries (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.orders(id) on delete cascade,
  courier_name text,
  tracking_number text,
  delivery_status text not null default 'pending',
  shipped_at timestamptz,
  delivered_at timestamptz
);

create table public.coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  discount_type text not null check (discount_type in ('fixed','percentage')),
  discount_value numeric(12,2) not null check (discount_value > 0),
  minimum_order numeric(12,2) not null default 0,
  starts_at timestamptz,
  expires_at timestamptz,
  usage_limit integer,
  is_active boolean not null default true
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  customer_id uuid references public.customers(id),
  rating integer not null check (rating between 1 and 5),
  comment text,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.suppliers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  email text,
  notes text,
  created_at timestamptz not null default now()
);

create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  description text not null,
  category text,
  amount numeric(12,2) not null check (amount >= 0),
  expense_date date not null default current_date,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id),
  action text not null,
  entity_type text not null,
  entity_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index products_category_active_idx on public.products(category, is_active);
create index products_featured_idx on public.products(is_featured) where is_active = true;
create index orders_status_created_idx on public.orders(status, created_at desc);
create index orders_phone_idx on public.orders(guest_phone);
create index inventory_product_created_idx on public.inventory_transactions(product_id, created_at desc);

-- Enable RLS. Public storefront can only read active products/categories.
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.product_variants enable row level security;
alter table public.profiles enable row level security;
alter table public.customers enable row level security;
alter table public.customer_addresses enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payments enable row level security;
alter table public.inventory_transactions enable row level security;
alter table public.deliveries enable row level security;
alter table public.coupons enable row level security;
alter table public.reviews enable row level security;
alter table public.suppliers enable row level security;
alter table public.expenses enable row level security;
alter table public.audit_logs enable row level security;

create policy "Public can view categories" on public.categories for select using (true);
create policy "Public can view active products" on public.products for select using (is_active = true);
create policy "Public can view variants of active products" on public.product_variants for select using (
  exists (select 1 from public.products p where p.id = product_id and p.is_active = true)
);

-- NOTE: Do not add anonymous INSERT policies for orders/payments.
-- Guest checkout must use a server-side API with strict validation, stock checks,
-- rate limiting and service-role credentials stored only on the server.
-- Admin policies should be added after implementing and testing role verification.
