import { createClient } from "@/lib/supabase/server";
import type { Product } from "@/lib/types";

export async function getFeaturedProducts(): Promise<Product[]> {
  try {
    const supabase = await createClient();
    const { data, error } = await supabase.from("products").select("*").eq("is_active", true).order("created_at", { ascending: false }).limit(8);
    if (error) throw error;
    return (data || []) as Product[];
  } catch { return []; }
}
export async function getProducts(category?: string): Promise<Product[]> {
  try {
    const supabase = await createClient();
    let query = supabase.from("products").select("*").eq("is_active", true).order("created_at", { ascending: false });
    if (category === "watch" || category === "perfume") query = query.eq("category", category);
    const { data, error } = await query;
    if (error) throw error;
    return (data || []) as Product[];
  } catch { return []; }
}
