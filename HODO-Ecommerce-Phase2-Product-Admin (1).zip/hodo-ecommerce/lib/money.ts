export const USD_TO_KHR = Number(process.env.NEXT_PUBLIC_KHR_PER_USD || 4100);
export const money = (amount: number, currency = "USD") =>
  new Intl.NumberFormat("en-US", { style: "currency", currency, maximumFractionDigits: 2 }).format(amount);
export const moneyBoth = (amount: number) => `${money(amount)} · ${new Intl.NumberFormat("en-US").format(Math.round(amount * USD_TO_KHR))}៛`;
