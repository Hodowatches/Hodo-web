export type Product = {
  id: string; name_en: string; name_km: string | null; slug: string;
  category: "watch" | "perfume"; brand: string | null; description_en: string | null;
  description_km: string | null; price: number; compare_at_price: number | null;
  image_url: string | null; sku: string | null; stock: number; is_active: boolean;
  gallery_urls?: string[] | null; attributes?: Record<string, unknown> | null;
};
export type CartLine = { product: Product; quantity: number };
