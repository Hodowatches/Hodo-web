# HODO E-Commerce Web App

Next.js 15 starter for a bilingual Khmer/English HODO watches and perfume store.

## Included
- Customer-facing storefront: homepage, shop filters, product detail pages
- USD and KHR price display (default display rate: 1 USD = 4,100 KHR)
- Supabase browser/server clients using the publishable key
- Admin sign-in with Supabase Auth and allow-list verification against `public.admin_users`
- Admin product catalogue: create, edit, activate/deactivate, stock quantity, bilingual names/descriptions, SKU and image upload
- Supabase Storage policies for public product image viewing and admin-only image management

## Important: use the database already configured for this HODO project
The current HODO Supabase database was created separately with these tables/columns:
- `public.products`: `name_en`, `name_km`, `slug`, `category`, `brand`, `description_en`, `description_km`, `price`, `compare_at_price`, `stock`, `image_url`, `is_active`, `sku`, `gallery_urls`, `attributes`, `sort_order`
- `public.admin_users`: `user_id`, `full_name`, `is_active`

**Do not run `supabase/schema.sql` against that existing database.** That file describes an older, different schema and is retained only as a reference for a fresh project. The admin page in this build targets the tables above.

## Configure locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env.local`.
3. Set `NEXT_PUBLIC_SUPABASE_URL` to `https://YOUR_PROJECT.supabase.co`.
4. Set `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` to your Supabase publishable key. Never put a secret key in a `NEXT_PUBLIC_` variable.
5. Run `npm install` then `npm run dev`.
6. Open `http://localhost:3000` for the customer store and `http://localhost:3000/admin` for the admin product manager.

## Storage setup
1. In Supabase Dashboard > Storage, create a bucket named `hodo-products` and enable **Public bucket**. Set the upload file-size limit to 5 MB and allowed MIME types to `image/jpeg`, `image/png`, `image/webp`.
2. Run `supabase/storage-policies.sql` in SQL Editor. It permits public image reads and restricts upload/update/delete to active users in `public.admin_users`.

## Admin login
- Create the admin user in Supabase Dashboard > Authentication > Users.
- Insert that user's UUID into `public.admin_users` with `is_active = true` (this has already been done for the first admin, according to the setup steps).
- Sign in at `/admin` using that Supabase Auth email and password.

## Current limitations — do not launch for real orders yet
- Cart page is still a placeholder; cart review and checkout are not implemented.
- Guest order API with server-side price validation, atomic stock reservation/decrement, rate limiting and spam protection is not implemented.
- ABA/KHQR are payment-method selections only; no payment gateway verification is connected. COD workflow is not complete.
- Admin order management, cancellation/restock, payment verification, delivery tracking, audit logging and analytics are not implemented.
- Khmer/English toggle and complete translation dictionary are not implemented; Khmer product fields can be entered and displayed.
- The KHR display rate is currently a simple configurable code default, not an editable admin setting.
- Add backups, monitoring, security review and end-to-end tests before production.

## Deploy outline
1. Push the project to a private GitHub repository.
2. Import it into Vercel.
3. Add the same public Supabase environment variables in Vercel project settings.
4. Deploy a preview and test storefront and admin login.
5. Add the purchased domain in Vercel and configure DNS at your domain registrar.
6. Test HTTPS and all workflows before announcing the store.

Never expose a Supabase secret/service-role key in browser code, GitHub or a `NEXT_PUBLIC_` variable. Rotate any key that has been exposed.
